﻿namespace WildFarm.Engines.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
