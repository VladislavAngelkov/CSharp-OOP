﻿namespace WildFarm.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
