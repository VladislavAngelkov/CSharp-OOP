﻿namespace WildFarm.Models.Interfaces
{
    public interface ISoundable
    {
        public string ProduceSound();
    }
}
