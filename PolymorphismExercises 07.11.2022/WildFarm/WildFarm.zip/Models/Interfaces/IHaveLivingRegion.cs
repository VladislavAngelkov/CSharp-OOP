﻿namespace WildFarm.Models.Interfaces
{
    public interface IHaveLivingRegion
    {
        public string LivingRegion { get; }
    }
}
