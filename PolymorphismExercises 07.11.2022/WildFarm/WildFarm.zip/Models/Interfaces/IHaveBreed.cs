﻿namespace WildFarm.Models.Interfaces
{
    public interface IHaveBreed
    {
         public string Breed { get; }
    }
}
