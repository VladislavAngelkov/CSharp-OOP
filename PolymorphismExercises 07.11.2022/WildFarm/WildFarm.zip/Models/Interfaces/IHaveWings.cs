﻿namespace WildFarm.Models.Interfaces
{
    public interface IHaveWings
    {
        public double WingSize { get; }
    }
}
