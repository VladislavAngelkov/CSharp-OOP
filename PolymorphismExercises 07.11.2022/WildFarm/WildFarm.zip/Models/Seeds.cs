﻿namespace WildFarm.Models
{
    public class Seeds : Food
    {
        public Seeds(int amount) 
            : base(amount)
        {
        }
    }
}
