﻿namespace WildFarm.Models
{
    public class Meat : Food
    {
        public Meat(int amount) 
            : base(amount)
        {
        }
    }
}
