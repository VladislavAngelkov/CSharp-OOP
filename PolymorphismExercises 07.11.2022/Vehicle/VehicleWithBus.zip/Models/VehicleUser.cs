﻿namespace Vehicle.Models
{
    using System;

    using IO.Interfaces;
    class VehicleUser
    {
        private Car car;
        private Truck truck;
        private Bus bus;
        private IWriter writer;

        public VehicleUser(Car car, Truck truck, IWriter writer)
        {
            this.car = car;
            this.truck = truck;
            this.writer = writer;
        }
        public VehicleUser(Car car, Truck truck, Bus bus, IWriter writer)
        {
            this.car = car;
            this.truck = truck;
            this.bus = bus;
            this.writer = writer;
        }

        public void UseVehicle(string info)
        {
            string[] commandInfo = info.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string command = commandInfo[0];
            string vehicle = commandInfo[1];
            double value = double.Parse(commandInfo[2]);

            if (command == "Drive")
            {
                if (vehicle == "Car")
                {
                    writer.WriteLine(car.Drive(value));
                }
                else if (vehicle == "Truck")
                {
                    writer.WriteLine(truck.Drive(value));
                }
                else if (vehicle == "Bus")
                {
                    writer.WriteLine(bus.Drive(value));
                }
            }
            else if (command == "Refuel")
            {
                if (vehicle == "Car")
                {
                    string refuelMessage = car.Refuel(value);
                    if (refuelMessage != null)
                    {
                        writer.WriteLine(refuelMessage);
                    }
                }
                else if (vehicle == "Truck")
                {
                    string refuelMessage = truck.Refuel(value);
                    if (refuelMessage != null)
                    {
                        writer.WriteLine(refuelMessage);
                    }
                }
                else if (vehicle == "Bus")
                {
                    string refuelMessage = bus.Refuel(value);
                    if (refuelMessage != null)
                    {
                        writer.WriteLine(refuelMessage);
                    }
                }
            }
            else if (command == "DriveEmpty")
            {
                writer.WriteLine(bus.DriveEmpty(value));
            }
        }
    }
}
