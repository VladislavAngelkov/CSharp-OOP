﻿namespace Vehicle.Models
{
    public class Car : Vehicle
    {
        public Car(double fuelQuantity, double fuelConsumption) 
            : base(fuelQuantity, fuelConsumption)
        {
            this.increasedFuelConsumption = 0.9;
            this.fuelLeftAfterRefuel = 1;
        }
    }
}
