﻿namespace Vehicle.Models
{
    using System;
    public class VehicleCreator
    {
        public static Car CreateCar(string info)
        {
            string[] carInfo = info.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            double carFuelQuantity = double.Parse(carInfo[1]);
            double carFuelConsumption = double.Parse(carInfo[2]);
            Car car = new Car(carFuelQuantity, carFuelConsumption);

            return car;
        }

        public static Truck CreateTruck(string info)
        {
            string[] truckInfo = info.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            double truckFuelQuantity = double.Parse(truckInfo[1]);
            double truckFuelConsumption = double.Parse(truckInfo[2]);
            Truck truck = new Truck(truckFuelQuantity, truckFuelConsumption);

            return truck;
        }
    }
}
