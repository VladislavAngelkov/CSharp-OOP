﻿
namespace Vehicle.Models
{
    using System;
    public abstract class Vehicle
    {
        private double fuelQuantity;
        private double fuelConsumption;
        private double traveledDistance;
        protected double increasedFuelConsumption;
        protected double fuelLeftAfterRefuel;

        protected Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity
        {
            get { return fuelQuantity; }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Fuel quantity cannot be negative number!");
                }
                fuelQuantity = value;
            }
        }

        public double FuelConsumption
        {
            get { return fuelConsumption; }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Fuel consumption cannot be negative number!");
                }
                fuelConsumption = value;
            }
        }
        public double TraveledDistance
        {
            get { return traveledDistance; }
            private set
            {
                traveledDistance = value;
            }
        }

        public string Drive(double kilometers)
        {
            double fuelNeeded = (FuelConsumption + increasedFuelConsumption) * kilometers;

            if (fuelNeeded>FuelQuantity)
            {
                return $"{this.GetType().Name} needs refueling";
            }

            TraveledDistance += kilometers;
            FuelQuantity -= fuelNeeded;

            return $"{this.GetType().Name} travelled {kilometers} km";
        }
        public void Refuel(double litters)
        {
            FuelQuantity += litters * fuelLeftAfterRefuel;
        }
    }
}
