﻿using System;
using System.Collections.Generic;
using System.Text;
using Vehicle.IO.Interfaces;

namespace Vehicle.Models
{
    class VehicleUser
    {
        private Car car;
        private Truck truck;
        private IWriter writer;


        public VehicleUser(Car car, Truck truck, IWriter writer)
        {
            this.car = car;
            this.truck = truck;
            this.writer = writer;
        }

        public void UseVehicle(string info)
        {
            string[] commandInfo = info.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string command = commandInfo[0];
            string vehicle = commandInfo[1];
            double value = double.Parse(commandInfo[2]);

            if (command == "Drive")
            {
                if (vehicle == "Car")
                {
                    writer.WriteLine(car.Drive(value));
                }
                else if (vehicle == "Truck")
                {
                    writer.WriteLine(truck.Drive(value));
                }
            }
            else if (command == "Refuel")
            {
                if (vehicle == "Car")
                {
                    car.Refuel(value);
                }
                else if (vehicle == "Truck")
                {
                    truck.Refuel(value);
                }
            }
        }
    }
}
