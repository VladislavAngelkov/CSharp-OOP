﻿namespace Vehicle.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
