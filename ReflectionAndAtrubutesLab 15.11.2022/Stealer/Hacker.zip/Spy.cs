﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string typeToInvestigate, params string[] fieldsToInvastigete)
        {
            Type type = Type.GetType(typeToInvestigate);
            object obj = Activator.CreateInstance(type);
            FieldInfo[] fields = type.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

            StringBuilder message = new StringBuilder();
            message.AppendLine($"Class under investigation: {type.Name}");

            foreach (var field in fields)
            {
                if (fieldsToInvastigete.Any(f => f == field.Name))
                {
                    object fieldValue = field.GetValue(obj);
                    message.AppendLine($"{field.Name} = {fieldValue}");
                }
            }

            return message.ToString().TrimEnd();
        }
    }
}
