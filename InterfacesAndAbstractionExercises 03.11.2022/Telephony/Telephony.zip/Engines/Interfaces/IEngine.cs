﻿namespace Telephony.Engine.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
