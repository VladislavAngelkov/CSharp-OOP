﻿namespace Telephony.Models.Interfaces
{
    public interface ICaller
    {
        public string Call(string number);
    }
}
