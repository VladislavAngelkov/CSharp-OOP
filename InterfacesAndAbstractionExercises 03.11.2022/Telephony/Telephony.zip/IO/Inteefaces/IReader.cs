﻿namespace Telephony.IO.Inteefaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
