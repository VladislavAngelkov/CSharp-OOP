﻿namespace CollectionHierarchy.Models.Interfaces
{
    public interface IRemover :IAdder
    {
        public string Remove();
    }
}
