﻿namespace CollectionHierarchy.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
