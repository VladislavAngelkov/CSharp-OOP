﻿namespace CollectionHierarchy.Engines.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
