﻿namespace ExplicitInterfaces.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
