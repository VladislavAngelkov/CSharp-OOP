﻿namespace ExplicitInterfaces.Engines.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
