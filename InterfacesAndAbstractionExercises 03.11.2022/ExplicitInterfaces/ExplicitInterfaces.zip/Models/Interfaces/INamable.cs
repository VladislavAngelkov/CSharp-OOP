﻿namespace ExplicitInterfaces.Models.Interfaces
{
    public interface INamable
    {
        public string Name { get;}
    }
}
