﻿namespace MilitaryElite.Enums
{
    public enum MissionState
    {
        inProgress,
        Finished
    }
}
