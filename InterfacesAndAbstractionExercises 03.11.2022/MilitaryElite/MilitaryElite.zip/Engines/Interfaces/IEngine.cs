﻿namespace MilitaryElite.Engines.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
