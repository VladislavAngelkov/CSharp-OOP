﻿namespace MilitaryElite.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
