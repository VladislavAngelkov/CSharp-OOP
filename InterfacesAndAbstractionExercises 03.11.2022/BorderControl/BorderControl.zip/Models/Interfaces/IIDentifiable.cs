﻿namespace BorderControl.Models.Interfaces
{
    public interface IIDentifiable
    {
        public string Id { get;}
    }
}
