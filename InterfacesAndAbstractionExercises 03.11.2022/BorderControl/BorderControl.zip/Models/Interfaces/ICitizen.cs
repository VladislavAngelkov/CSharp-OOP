﻿namespace BorderControl.Models.Interfaces
{
    public interface ICitizen : IIDentifiable
    {
        public string Name { get;}
        public int Age { get;}
    }
}
