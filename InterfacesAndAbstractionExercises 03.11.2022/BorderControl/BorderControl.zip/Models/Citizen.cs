﻿namespace BorderControl.Models
{
    using BorderControl.Exceptions;
    using BorderControl.Models.Interfaces;
    public class Citizen : ICitizen
    {
        private string name;
        private int age;
        private string id;

        public Citizen(string name, int age, string id)
        {
            this.Name = name;
            this.Age = age;
            this.Id = id;
        }

        public string Name
        {
            get { return name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new InvalidNameException();
                }
                name = value;
            }
        }

        public int Age
        {
            get { return age; }
            private set
            {
                if (value<0)
                {
                    throw new InvalidAgeException();
                }
                age = value;
            }
        }

        public string Id
        {
            get { return id; } 
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new InvalidNameException();
                }
                id = value;
            }
        }
    }
}
