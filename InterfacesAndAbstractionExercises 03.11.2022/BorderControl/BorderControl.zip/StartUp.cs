﻿namespace BorderControl
{
    using BorderControl.Engines;
    using BorderControl.IO;
    using BorderControl.IO.Interfaces;
    class StartUp
    {
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsoleWriter();

            Engine engine = new Engine(reader, writer);
            engine.Run();
        }
    }
}
