﻿namespace BorderControl.Models.Interfaces
{
    public interface IRobot : IIDentifiable
    {
        public string Model { get;}
    }
}
