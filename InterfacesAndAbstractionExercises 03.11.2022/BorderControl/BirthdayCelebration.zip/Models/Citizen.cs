﻿namespace BorderControl.Models
{
    using BorderControl.Exceptions;
    using BorderControl.Models.Interfaces;
    using System;

    public class Citizen : ICitizen, IBirthable
    {
        private string name;
        private int age;
        private string id;
        private DateTime birthDate;

        public Citizen(string name, int age, string id)
        {
            this.name = name;
            this.age = age;
            this.id = id;
        }

        public Citizen(string name, int age, string id, string birthDate)
            : this (name, age, id)
        {
            string[] birthInfo = birthDate.Split("/");
            int day = int.Parse(birthInfo[0]);
            int month = int.Parse(birthInfo[1]);
            int year = int.Parse(birthInfo[2]);
            this.BirthDate = new DateTime(year, month, day);
        }

        public string Name
        {
            get { return name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new InvalidNameException();
                }
                name = value;
            }
        }

        public int Age
        {
            get { return age; }
            private set
            {
                if (value<0)
                {
                    throw new InvalidAgeException();
                }
                age = value;
            }
        }

        public string Id
        {
            get { return id; } 
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new InvalidNameException();
                }
                id = value;
            }
        }
        public DateTime BirthDate
        {
            get { return birthDate; }
            private set
            {
                birthDate = value;
            }
        }

    }
}
