﻿namespace BorderControl.Models.Interfaces
{
    public interface IRebel
    {
        public string Group { get; }
    }
}
