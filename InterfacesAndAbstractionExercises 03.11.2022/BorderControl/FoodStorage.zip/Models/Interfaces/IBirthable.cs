﻿
namespace BorderControl.Models.Interfaces
{
    using System;
    public interface IBirthable
    {
        public DateTime BirthDate { get; }
    }
}
