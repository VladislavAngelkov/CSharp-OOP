﻿namespace BorderControl.IO.Interfaces
{
    public interface IReader
    {
        public string ReadLine();
    }
}
